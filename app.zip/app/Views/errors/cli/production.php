<?php

// On the CLI, we still want errors in productions
// so just use the exception template.
include __DIR__ . '/error_exception.php';

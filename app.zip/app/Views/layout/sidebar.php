<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <?= $this->include('layout/sidebar_header'); ?>
        <?= $this->include('layout/sidebar_menu'); ?>
    </div>
</div>
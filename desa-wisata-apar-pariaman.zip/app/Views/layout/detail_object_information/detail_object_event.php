<tr>
    <td class="fw-bold">Name</td>
    <td><?= $objectData->name; ?></td>
</tr>

<tr>
    <td class="fw-bold">Date Start</td>
    <td><?= $objectData->date_start; ?></td>
</tr>
<tr>
    <td class="fw-bold">Date End</td>
    <td><?= $objectData->date_end; ?></td>
</tr>
<tr>
    <td class="fw-bold">Time</td>
    <td><?= $objectData->time_start; ?>-<?= $objectData->time_end; ?> WIB</td>
</tr>
<tr>
    <td class="fw-bold">Price</td>
    <td><?= $objectData->price; ?> IDR</td>
</tr>

<tr>
    <td class="fw-bold">Contact Person</td>
    <td><?= $objectData->contact_person; ?></td>
</tr>
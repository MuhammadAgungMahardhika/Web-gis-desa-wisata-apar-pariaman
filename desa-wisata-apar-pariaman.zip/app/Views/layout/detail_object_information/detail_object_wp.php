<tr>
    <td class="fw-bold">Name</td>
    <td><?= $objectData->name; ?></td>
</tr>

<tr>
    <td class="fw-bold">Category</td>
    <td><?= $objectData->category; ?></td>
</tr>
<tr>
    <td class="fw-bold">Open</td>
    <td><?= $objectData->open; ?></td>
</tr>
<tr>
    <td class="fw-bold">Close</td>
    <td><?= $objectData->close; ?></td>
</tr>
<tr>
    <td class="fw-bold">Building size</td>
    <td><?= $objectData->building_size; ?></td>
</tr>
<tr>
    <td class="fw-bold">Capacity</td>
    <td><?= $objectData->capacity; ?></td>
</tr>
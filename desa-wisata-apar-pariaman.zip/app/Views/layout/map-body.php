<div class="card-body">
    <div class="googlemaps" id="map" onload="initMap();" style="min-height: 60vh;">
    </div>
</div>
  <!-- Footer -->
  <footer>
      <div class="footer clearfix mb-0 text-muted">
          <div class="float-start">
              <p>2021 &copy; Muhammad Agung Mahardhika</p>
          </div>
          <div class="float-end">
              <p>keep in touch <i class="fa fa-envelope"></i> <a href="mailto:m.agungmahardika12@gmail.com"> m.agungmahardika12@gmail.com</a></p>
          </div>
      </div>
  </footer>
  <!-- End of Footer -->